#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <unordered_map>

using namespace std;

struct Course {
    string courseNumber;
    string courseTitle;
    vector<string> prerequisites;
};

void loadCourses(const string& filename, vector<Course>& courses, unordered_map<string, Course>& courseMap) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return;
    }

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        string courseNumber, courseTitle, prereq;
        getline(ss, courseNumber, ',');
        getline(ss, courseTitle, ',');

        Course course;
        course.courseNumber = courseNumber;
        course.courseTitle = courseTitle;

        while (getline(ss, prereq, ',')) {
            course.prerequisites.push_back(prereq);
        }

        courses.push_back(course);
        courseMap[courseNumber] = course;
    }

    file.close();
}

void printCourseList(const vector<Course>& courses) {
    for (const auto& course : courses) {
        cout << course.courseNumber << ", " << course.courseTitle << endl;
    }
}

void printCourseInfo(const unordered_map<string, Course>& courseMap, const string& courseNumber) {
    auto it = courseMap.find(courseNumber);
    if (it != courseMap.end()) {
        const Course& course = it->second;
        cout << course.courseNumber << ", " << course.courseTitle << endl;
        cout << "Prerequisites: ";
        for (const auto& prereq : course.prerequisites) {
            cout << prereq << " ";
        }
        cout << endl;
    }
    else {
        cout << "Course not found." << endl;
    }
}

int main() {
    vector<Course> courses;
    unordered_map<string, Course> courseMap;
    int choice;
    string filename, courseNumber;

    cout << "Welcome to the course planner." << endl;

    while (true) {
        cout << "1. Load Data Structure." << endl;
        cout << "2. Print Course List." << endl;
        cout << "3. Print Course." << endl;
        cout << "9. Exit" << endl;
        cout << "What would you like to do? ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter the file name: ";
            cin >> filename;
            loadCourses(filename, courses, courseMap);
            sort(courses.begin(), courses.end(), [](const Course& a, const Course& b) {
                return a.courseNumber < b.courseNumber;
                });
            break;
        case 2:
            printCourseList(courses);
            break;
        case 3:
            cout << "What course do you want to know about? ";
            cin >> courseNumber;
            printCourseInfo(courseMap, courseNumber);
            break;
        case 9:
            cout << "Thank you for using the course planner!" << endl;
            return 0;
        default:
            cout << choice << " is not a valid option." << endl;
            break;
        }
    }

    return 0;
}